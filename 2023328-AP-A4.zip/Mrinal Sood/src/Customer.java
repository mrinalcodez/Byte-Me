import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;

public class Customer extends User implements OrderInterface {
    public ArrayList<Cart> cart = new ArrayList<>();

    public Customer(String name){
        super(name);
        customers.add(this);
    }

    public void upgrade(){
        VIP vip = new VIP(this.name);
        vip.updateDetails(this);
        customers.remove(this);
    }

    @Override
    public String viewOrders() {
        StringBuilder orderlist = new StringBuilder();
        for(Order order : Admin.normal_orders){
            if(order.customer.name.equals(name)) {
                orderlist.append("ID: ").append(order.id).append(" ").append("Item: ").append(order.food.name).append(" ").append("Price: ").append(order.food.price).append(" ").append("Quantity: ").append(order.getQuantity()).append(" ").append("Special Requests: ").append(order.getSpecial_requests()).append(" ").append("Status: ").append(order.getStatus().getStatus()).append("\n");
            }
        }
        return orderlist.toString();
    }

    public String searchItem(String name){
        StringBuilder search = new StringBuilder();
        for(Food item : Admin.items){
            if(item.name.equals(name)){
                search.append("Item: ").append(item.name).append(" ").append("Price: ").append(item.price).append(" ").append("Availability: ").append(item.availability).append("\n");
            }
        }
        return search.toString();
    }

    public String filter(String category) {
        StringBuilder filter = new StringBuilder();
        for (Food item : Admin.items) {
            if (item.category.equals(category)) {
                filter.append("Item: ").append(item.name).append(" ").append("Price: ").append(item.price).append(" ").append("Availability: ").append(item.availability).append("\n");
            }
        }
        return filter.toString();
    }

    public String sortByPrice(boolean ascending){
        ArrayList<Food> menu = Admin.items;
        if(!ascending){
            menu.sort(Comparator.comparing((Food food) -> food.price).reversed());
        } else {
            menu.sort(Comparator.comparing(food -> food.price));
        }
        StringBuilder price_sort = new StringBuilder();
        for(Food food : menu){
            price_sort.append("Item: ").append(food.name).append(" ").append("Price: ").append(food.price).append(" ").append("Category: ").append(food.category).append(" ").append("Availability: ").append(food.availability).append("\n");
        }
        return price_sort.toString();
    }

    public void addItem(String name, int quantity){
        if(quantity < 0){
            System.out.println("Invalid quantity");
        }
        for(Food item : Admin.items){
            if(item.name.equals(name) && item.availability){
                cart.add(new Cart(cart.size(), item, quantity, this));
            } else if(!item.availability){
                System.out.println("Sorry not available!");
            }
        }
    }

    public void changeQuantity(String name, int quantity) {
        for (Cart c : cart) {
            if (c.food.name.equals(name)) {
                int newQuantity = c.quantity + quantity;
                if (newQuantity < 0) {
                    throw new IllegalArgumentException("Quantity cannot be negative");
                }
                c.quantity = newQuantity;
                return;
            }
        }
        throw new IllegalArgumentException("Item not found in cart");
    }

    public void removeItem(String name){
        Cart cart1 = null;
        for (Cart c : cart){
            if(c.food.name.equals(name)){
                cart1 = c;
            }
        }
        cart.remove(cart1);
    }

    public String viewCart(){
        StringBuilder cart_items = new StringBuilder();
        for(Cart c : cart){
            cart_items.append("ID: ").append(c.id).append(" ").append("Item: ").append(c.food.name).append(" ").append("Quantity: ").append(c.quantity).append(" ").append("Total price: ").append(c.food.price*c.quantity).append("\n");
        }
        return cart_items.toString();
    }

    public void checkout(String[] args){
        int[] ids = new int[args.length];
        for(int i = 0; i < ids.length; i++){
            ids[i] = Admin.normal_orders.size() + i;
        }
        for(int i = 0; i < cart.size(); i++){
            cart.get(i).placeOrder(ids[i], args[i]);
        }
    }

    public void cancelOrder(int id){
        for(Order order : Admin.normal_orders){
            if(order.id == id) {
                order.cancelOrder();
                break;
            }
        }
    }

    public String OrderHistory(){
        StringBuilder history = new StringBuilder();
        for(Order order : Admin.completed_orders){
            if(order.customer.name.equals(name)){
                history.append("ID: ").append(order.id).append(" ").append("Item: ").append(order.food.name).append(" ").append("Quantity: ").append(order.getQuantity()).append(" ").append("Special Requests: ").append(order.getSpecial_requests()).append(" ").append("Status: ").append(order.getStatus().getStatus()).append("\n");
            }
        }
        for(Order order : Admin.cancelled_orders){
            if(order.customer.name.equals(name)) {
                history.append("ID: ").append(order.id).append(" ").append("Item: ").append(order.food.name).append(" ").append("Quantity: ").append(order.getQuantity()).append(" ").append("Special Requests: ").append(order.getSpecial_requests()).append(" ").append("Status: ").append(order.getStatus().getStatus()).append("\n");
            }
        }
        return history.toString();
    }

    public void leaveReview(Food food, String comment){
        food.reviews.put(this, comment);
    }

    public String viewReviews(Food food){
        StringBuilder reviews = new StringBuilder();
        for(Customer customer : food.reviews.keySet()){
            reviews.append(customer.name).append(":\n").append(food.reviews.get(customer)).append("\n");
        }
        return reviews.toString();
    }
}
