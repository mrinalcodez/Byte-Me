public interface MenuInterface {
    public String viewMenu();
}
