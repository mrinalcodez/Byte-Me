import java.util.ArrayList;

public class VIP extends Customer{
    public VIP(String name) {
        super(name);
    }

    public void updateDetails(Customer customer){
        this.cart = customer.cart;
        ArrayList<Order> orders = new ArrayList<>();
        for(Order order : Admin.normal_orders){
            if(customer.name.equals(order.customer.name)){
                order.customer = this;
                Admin.vip_orders.add(order);
                orders.add(order);
            }
        }
        for(Order order : Admin.completed_orders){
            if(customer.name.equals(order.customer.name)){
                order.customer = this;
            }
        }
        for(Order order : Admin.cancelled_orders){
            if(customer.name.equals(order.customer.name)){
                order.customer = this;
            }
        }
        for(Order order : orders){
            Admin.normal_orders.remove(order);
        }
    }

    @Override
    public void cancelOrder(int id) {
        for(Order order : Admin.vip_orders){
            if(order.id == id) {
                order.cancelOrder();
                break;
            }
        }
    }

    @Override
    public String viewOrders() {
        StringBuilder orderlist = new StringBuilder();
        for(Order order : Admin.vip_orders){
            if(order.customer.name.equals(name)) {
                orderlist.append("ID: ").append(order.id).append(" ").append("Item: ").append(order.food.name).append(" ").append("Price: ").append(order.food.price).append(" ").append("Quantity: ").append(order.getQuantity()).append(" ").append("Special Requests: ").append(order.getSpecial_requests()).append(" ").append("Status: ").append(order.getStatus().getStatus()).append("\n");
            }
        }
        return orderlist.toString();
    }

    @Override
    public void checkout(String[] args){
        int[] ids = new int[args.length];
        for(int i = 0; i < ids.length; i++){
            ids[i] = Admin.vip_orders.size() + i;
        }
        for(int i = 0; i < cart.size(); i++){
            cart.get(i).placeOrder(ids[i], args[i]);
        }
    }
}
