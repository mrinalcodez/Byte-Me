import org.junit.Test;

import static org.junit.Assert.*;

public class LoginTest {

    @Test
    public void testLoginForAdminSuccess() {
        // Arrange: Create an admin user and add it to the list
        Admin admin = new Admin("testAdmin");
        User.admins.add(admin);

        // Act: Call the login method
        User result = Main.login("admin", "testAdmin");

        // Assert: Verify that the correct user is returned
        assertEquals("Returned user should match the expected admin.", admin, result);
    }

    @Test
    public void testLoginForCustomerSuccess() {
        // Arrange: Create a customer user and add it to the list
        Customer customer = new Customer("testCustomer");
        User.customers.add(customer);

        // Act: Call the login method
        User result = Main.login("customer", "testCustomer");

        // Assert: Verify that the correct user is returned
        assertEquals("Returned user should match the expected customer.", customer, result);
    }

    @Test
    public void testLoginForNonExistentAdmin() {
        // Act: Call the login method for a non-existent admin
        User result = Main.login("admin", "nonExistentAdmin");

        // Assert: Verify that null is returned
        assertNull(result);
    }

    @Test
    public void testLoginForNonExistentCustomer() {
        // Act: Call the login method for a non-existent customer
        User result = Main.login("customer", "nonExistentCustomer");

        // Assert: Verify that null is returned
        assertNull("Login should return null for a non-existent customer.", result);
    }

    @Test
    public void testLoginWithInvalidMode() {
        // Act: Call the login method with an invalid mode
        User result = Main.login("invalidMode", "testUser");

        // Assert: Verify that null is returned
        assertNull("Login should return null when the mode is invalid.", result);
    }
}