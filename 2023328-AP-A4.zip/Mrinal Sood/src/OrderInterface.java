public interface OrderInterface {
    public String viewOrders();
}
