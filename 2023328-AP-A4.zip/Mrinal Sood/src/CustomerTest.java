import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CustomerTest {
    private Customer customer;
    private Food food;

    @Before
    public void setUp(){
        customer = new Customer("Mrinal");
        Admin.items.clear();
        food = new Food("Burger", 50, "Fast food", true);
        Admin.items.add(food);
    }

    @Test
    public void addItem() {
        customer.addItem("Burger", 2);

        assertEquals(1, customer.cart.size());
        Cart cartItem = customer.cart.get(0);

        assertEquals("Burger", cartItem.food.name);
        assertEquals(2, cartItem.quantity);

        float expectedTotalPrice = 100.0f;
        float actualTotalPrice = cartItem.food.price * cartItem.quantity;
        float delta = 0.01f;

        assertEquals(expectedTotalPrice, actualTotalPrice, delta);
    }

    @Test
    public void changeQuantity() {
        customer.addItem("Burger", 1);
        Cart cartItem = customer.cart.get(0);

        assertEquals(1, cartItem.quantity);
        assertEquals(50.0f, cartItem.food.price * cartItem.quantity, 0.001f);

        customer.changeQuantity("Burger", 2);
        assertEquals(3, cartItem.quantity);
        assertEquals(150.0f, cartItem.food.price * cartItem.quantity, 0.001f);

        customer.changeQuantity("Burger", 1);
        assertEquals(4, cartItem.quantity);
        assertEquals(200.0f, cartItem.food.price * cartItem.quantity, 0.001f);

        customer.changeQuantity("Burger", -4);
        assertEquals(0, cartItem.quantity);
        assertEquals(0.0f, cartItem.food.price * cartItem.quantity, 0.001f);

        assertThrows(IllegalArgumentException.class, () -> customer.changeQuantity("Burger", -1));
        assertEquals(0, cartItem.quantity);
        assertEquals(0.0f, cartItem.food.price * cartItem.quantity, 0.001f);
    }

}