import java.util.ArrayList;
import java.util.HashMap;

public class Food {
    public String name;
    public float price;
    public boolean availability;
    public String category;
    public HashMap<Customer, String> reviews = new HashMap<>();

    public Food(String name, float price, String category, boolean availability){
        this.name = name;
        this.price = price;
        this.availability = availability;
        this.category = category;
    }


}
