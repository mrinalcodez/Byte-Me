import java.util.ArrayList;

public abstract class User implements MenuInterface {
    protected String name;

    public User(String name){
        this.name = name;
    }

    public static ArrayList<Admin> admins = new ArrayList<>();
    public static ArrayList<Customer> customers = new ArrayList<>();

    @Override
    public String viewMenu() {
        StringBuilder menu_items = new StringBuilder();
        for(Food item : Admin.items){
            menu_items.append("Item: ").append(item.name).append(" ").append("Price: ").append(item.price).append(" ").append("Category: ").append(item.category).append(" ").append("Availability: ").append(item.availability).append("\n");
        }
        return menu_items.toString();
    }
}
