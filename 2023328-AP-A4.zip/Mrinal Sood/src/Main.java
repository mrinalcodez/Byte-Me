import java.io.FileReader;
import java.util.Comparator;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static User login(String mode, String name){
        if(mode.equals("admin")){
            for(Admin admin : User.admins){
                if(admin.name.equals(name)){
                    return admin;
                }
            }
            return null;
        } else if (mode.equals("customer")) {
            for (Customer customer : User.customers){
                if(customer.name.equals(name)){
                    return customer;
                }
            }
            return null;
        }
        return null;
    }

    public static void user_interface(User user){
        Scanner scanner = new Scanner(System.in);
        if(user instanceof Admin admin){
            int option;
            do {
                System.out.println("1. Add new item in menu");
                System.out.println("2. Remove item from menu");
                System.out.println("3. Update item in menu");
                System.out.println("4. View pending orders");
                System.out.println("5. Update order status");
                System.out.println("6. Daily sales report");
                System.out.println("7. Logout");
                option = scanner.nextInt();
                scanner.nextLine();
                if(option == 1){
                    System.out.println("Enter new food item: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter price: ");
                    float price = scanner.nextFloat();
                    scanner.nextLine();
                    System.out.println("Enter category: ");
                    String category = scanner.nextLine();
                    admin.addItem(name, category, price);
                } else if(option == 2){
                    System.out.println("Enter item to remove: ");
                    String name = scanner.nextLine();
                    admin.removeItem(name);
                } else if(option == 3){
                    System.out.println("Enter item which you want to update: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter what you want to update(Price/availability)");
                    String update = scanner.nextLine();
                    if(update.equals("Price")){
                        System.out.println("Enter the new price: ");
                        float price = scanner.nextFloat();
                        admin.updateItem(name, price);
                    } else if(update.equals("availability")){
                        System.out.println("Enter availability(y/n)");
                        String availability = scanner.nextLine();
                        admin.updateItem(name, availability.equals("y"));
                    }
                } else if(option == 4){
                    System.out.println(admin.viewOrders());
                } else if(option == 5){
                    Admin.vip_orders.sort(Comparator.comparingInt((Order order) -> order.getStatus().getPriority()).reversed());
                    Admin.normal_orders.sort(Comparator.comparingInt((Order order) -> order.getStatus().getPriority()).reversed());
                    System.out.println(admin.viewOrders());
                    System.out.println("Enter new status for the order: ");
                    String status = scanner.nextLine();
                    admin.updateOrderStatus(status);
                } else if(option == 6){
                    System.out.println("Generating daily report...");
                    System.out.println(admin.dailyReport());
                }
            } while (option != 7);
        }
        else if(user instanceof Customer customer){
            int option;
            do {
                System.out.println("1. Upgrade to VIP");
                System.out.println("2. View all items");
                System.out.println("3. Search item");
                System.out.println("4. Sort by price");
                System.out.println("5. Filter by category");
                System.out.println("6. Add to cart");
                System.out.println("7. Remove from cart");
                System.out.println("8. Change quantity of item in cart");
                System.out.println("9. View total");
                System.out.println("10. Live tracking of orders");
                System.out.println("11. Checkout");
                System.out.println("12. View order history");
                System.out.println("13. Cancel order");
                System.out.println("14. Leave review");
                System.out.println("15. View reviews");
                System.out.println("16. Logout");
                option = scanner.nextInt();
                scanner.nextLine();
                if(option == 1){
                    customer.upgrade();
                    System.out.println("Woohoo! You are now a VIP");
                    break;
                } else if(option == 2){
                    System.out.println(customer.viewMenu());
                } else if(option == 3){
                    System.out.println("Enter item you want to search: ");
                    String name = scanner.nextLine();
                    System.out.println(customer.searchItem(name));
                } else if(option == 4){
                    System.out.println("Low to High or High to Low");
                    String filter = scanner.nextLine();
                    System.out.println(customer.sortByPrice(filter.equals("Low to High")));
                } else if(option == 5){
                    System.out.println("Select category(Snacks/Beverages/Main Course/Desserts): ");
                    String category = scanner.nextLine();
                    System.out.println(customer.filter(category));
                } else if(option == 6){
                    System.out.println("Enter item name: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine();
                    customer.addItem(name, quantity);
                } else if(option == 7){
                    System.out.println("Enter item to remove from cart: ");
                    String name = scanner.nextLine();
                    customer.removeItem(name);
                } else if(option == 8){
                    System.out.println("Enter item name: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine();
                    customer.changeQuantity(name, quantity);
                } else if(option == 9){
                    System.out.println(customer.viewCart());
                } else if (option == 10) {
                    System.out.println(customer.viewOrders());
                } else if (option == 11) {
                    System.out.println(customer.viewCart());
                    String[] names = new String[customer.cart.size()];
                    for(int i = 0; i < names.length; i++){
                        System.out.println("Any special requests: ");
                        String name = scanner.nextLine();
                        names[i] = name;
                    }
                    customer.checkout(names);
                } else if (option == 12) {
                    System.out.println(customer.OrderHistory());
                    System.out.println("Do you want to reorder?(y/n)");
                    String choice = scanner.nextLine();
                    if(choice.equals("y")){
                        String[] names = new String[customer.cart.size()];
                        for(int i = 0; i < names.length; i++){
                            System.out.println("Any special requests: ");
                            String name = scanner.nextLine();
                            names[i] = name;
                        }
                        customer.checkout(names);
                    }
                } else if(option == 13){
                    System.out.println(customer.viewOrders());
                    System.out.println("Enter order id: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    customer.cancelOrder(id);
                } else if(option == 14){
                    System.out.println("Enter food item: ");
                    String name = scanner.nextLine();
                    for(Food food : Admin.items){
                        if(food.name.equals(name)) {
                            System.out.println("Add comment: ");
                            String comment = scanner.nextLine();
                            customer.leaveReview(food, comment);
                            break;
                        }
                    }
                } else if(option == 15){
                    System.out.println("Enter food item: ");
                    String name = scanner.nextLine();
                    for (Food food : Admin.items) {
                        if (food.name.equals(name)) {
                            System.out.println(customer.viewReviews(food));
                            break;
                        }
                    }
                }
            } while(option != 16);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("Welcome to Byte Me!");
            System.out.println("1. Sign up");
            System.out.println("2. Login");
            System.out.println("3. exit");
            choice = scanner.nextInt();
            scanner.nextLine();
            if(choice == 1){
                System.out.println("Enter mode: ");
                String mode = scanner.nextLine();
                System.out.println("Enter name: ");
                String name = scanner.nextLine();
                if(mode.equals("admin")){
                    new Admin(name);
                } else if(mode.equals("customer")){
                    new Customer(name);
                }
            } else if(choice == 2){
                System.out.println("Enter mode: ");
                String mode = scanner.nextLine();
                System.out.println("Enter name: ");
                String name = scanner.nextLine();
                if(login(mode, name) != null){
                    user_interface(login(mode, name));
                }
            }
        } while (choice != 3);
    }
}