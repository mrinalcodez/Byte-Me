module com.example.assignment4_extension {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.example.assignment4_extension to javafx.fxml;
    exports com.example.assignment4_extension;
}