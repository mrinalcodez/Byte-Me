package com.example.assignment4_extension;

public interface MenuInterface {
    public String viewMenu();
}
