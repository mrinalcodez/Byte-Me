package com.example.assignment4_extension;

import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

import java.util.ArrayList;

public class MenuController extends Controller {

    @FXML
    public ScrollPane scrollPane;

    @FXML
    public GridPane gridPane;


    public void initialize(){
        gridPane.prefWidthProperty().bind(scrollPane.widthProperty());
        gridPane.prefHeightProperty().bind(scrollPane.heightProperty());
    }

    public void addItem(ArrayList<String> array){
        int row = emptyRow(gridPane);
        for (int i = 0; i < array.size(); i++){
            Label label = new Label(array.get(i));
            label.setFont(Font.font("Dubai", 37));
            GridPane.setValignment(label, VPos.CENTER);
            GridPane.setHalignment(label, HPos.CENTER);
            gridPane.add(label, i, row);
        }
    }


    private int emptyRow(GridPane gridPane){
        int row = 0;
        for(var child : gridPane.getChildren()){
            Integer rowIndex = GridPane.getRowIndex(child);
            if(rowIndex == null){
                rowIndex = 0;
            }
            row = Math.max(row, rowIndex + 1);
        }
        return row;
    }
}
