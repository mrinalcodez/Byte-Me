package com.example.assignment4_extension;

import java.util.ArrayList;

public class SceneManager {
    private final ArrayList<javafx.scene.Scene> scenes = new ArrayList<>();
    private SceneChangeListener listener;

    // Add a scene and notify the listener
    public void addScene(javafx.scene.Scene scene) {
        scenes.add(scene);
        if (listener != null) {
            listener.onSceneAdded(scene);
        }
    }

    // Get the current scenes list
    public ArrayList<javafx.scene.Scene> getScenes() {
        return scenes;
    }

    // Set the scene change listener
    public void setSceneChangeListener(SceneChangeListener listener) {
        this.listener = listener;
    }

    // Listener interface for scene changes
    public interface SceneChangeListener {
        void onSceneAdded(javafx.scene.Scene newScene);
    }
}

