package com.example.assignment4_extension;

import java.util.*;

public class Admin extends User implements OrderInterface {
    public static Map<String, Integer> popular_foods = new HashMap<>();
    public static ArrayList<Food> items = new ArrayList<>();
    public static ArrayList<Order> normal_orders = new ArrayList<>();
    public static ArrayList<Order> vip_orders = new ArrayList<>();
    public static ArrayList<Order> completed_orders = new ArrayList<>();
    public static ArrayList<Order> cancelled_orders = new ArrayList<>();

    public Admin(String name) {
        super(name);
        admins.add(this);
    }

    public void addItem(String name, String category, float price) {
        Food new_item = new Food(name, price, category, true);
        items.add(new_item);
        popular_foods.put(new_item.name, popular_foods.getOrDefault(new_item.name, 0) + 1);
    }

    public void removeItem(String name) {
        Food food = null;
        for (Food item : items) {
            if (item.name.equals(name)) {
                food = item;
            }
        }
        assert food != null;
        items.remove(food);
        ArrayList<Order> updates = new ArrayList<>();
        for (Order order : normal_orders) {
            if (order.food.name.equals(food.name)) {
                order.updateStatus("DENIED");
                updates.add(order);
                Admin.cancelled_orders.add(order);
            }
        }
        for (Order order : vip_orders) {
            if (order.food.name.equals(food.name)) {
                order.updateStatus("DENIED");
                updates.add(order);
                Admin.cancelled_orders.add(order);
            }
        }
        for (Order update : updates) {
            if (normal_orders.contains(update)) {
                normal_orders.remove(update);
            } else vip_orders.remove(update);
        }
    }

    public <T> void updateItem(String name, T field) {
        for (Food item : items) {
            if (item.name.equals(name)) {
                if (field instanceof Float) {
                    item.price = (float) field;
                } else if (field instanceof Boolean) {
                    item.availability = (boolean) field;
                }
            }
        }
    }

    public void updateOrderStatus(String status) {
        if (checkforVIP()) {
            vip_orders.sort(Comparator.comparingInt((Order order) -> order.getStatus().getPriority()).reversed());
            if(vip_orders.get(0).getStatus() == Order.Status.CANCELLED || vip_orders.get(0).getStatus() == Order.Status.DENIED){
                for(Order order : cancelled_orders){
                    if(order.id == vip_orders.get(0).id){
                        order.updateStatus("REFUNDED");
                        break;
                    }
                }
            }
            vip_orders.get(0).updateStatus(status);
            if (vip_orders.get(0).getStatus() == Order.Status.DELIVERED) {
                completed_orders.add(vip_orders.get(0));
                popular_foods.put(vip_orders.get(0).food.name, popular_foods.getOrDefault(vip_orders.get(0).food.name, 0) + 1);
                Admin.vip_orders.remove(vip_orders.get(0));
            } else if(vip_orders.get(0).getStatus() == Order.Status.REFUNDED){
                Admin.vip_orders.remove(vip_orders.get(0));
            }
        } else {
            normal_orders.sort(Comparator.comparingInt((Order order) -> order.getStatus().getPriority()).reversed());
            if(normal_orders.get(0).getStatus() == Order.Status.CANCELLED || normal_orders.get(0).getStatus() == Order.Status.DENIED){
                for(Order order : cancelled_orders){
                    if(order.id == normal_orders.get(0).id){
                        order.updateStatus("REFUNDED");
                        break;
                    }
                }
            }
            normal_orders.get(0).updateStatus(status);
            if (normal_orders.get(0).getStatus() == Order.Status.DELIVERED) {
                completed_orders.add(normal_orders.get(0));
                popular_foods.put(normal_orders.get(0).food.name, popular_foods.getOrDefault(normal_orders.get(0).food.name, 0) + 1);
                Admin.normal_orders.remove(normal_orders.get(0));
            } else if(normal_orders.get(0).getStatus() == Order.Status.REFUNDED){
                Admin.normal_orders.remove(normal_orders.get(0));
            }
        }
    }

    @Override
    public String viewOrders() {
        StringBuilder pending = new StringBuilder();
        for (Order o : vip_orders) {
            pending.append("Customer: ").append(o.customer.name).append(" ").append("Item: ").append(o.food.name).append(" ").append("Quantity: ").append(o.getQuantity()).append(" ").append("Status: ").append(o.getStatus().getStatus()).append(" ").append("Special_requests: ").append(o.getSpecial_requests()).append("\n");
        }
        for (Order o : normal_orders) {
            pending.append("Customer: ").append(o.customer.name).append(" ").append("Item: ").append(o.food.name).append(" ").append("Quantity: ").append(o.getQuantity()).append(" ").append("Status: ").append(o.getStatus().getStatus()).append(" ").append("Special_requests: ").append(o.getSpecial_requests()).append("\n");
        }
        return pending.toString();
    }

    private boolean checkforVIP() {
        return !vip_orders.isEmpty();
    }

    public String dailyReport() {
        float total_sales = 0;
        for(Order order : completed_orders){
            total_sales += order.food.price * order.getQuantity();
        }
        StringBuilder sales = new StringBuilder();
        sales.append("Total sales: ").append(total_sales).append("\n").append("Most popular items: ").append("\n");
        for(String keys : popular_foods.keySet()){
            if(popular_foods.get(keys).equals(Collections.max(popular_foods.values()))){
                sales.append(keys).append("\n");
            }
        }
        sales.append("Total orders: ").append(completed_orders.size()).append("\n");
        return sales.toString();
    }

}
