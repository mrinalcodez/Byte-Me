package com.example.assignment4_extension;

public interface OrderInterface {
    public String viewOrders();
}
