package com.example.assignment4_extension;

public class Order {
    int id;
    Customer customer;
    Food food;
    private int quantity;
    private Status status;
    private String special_requests;
    
    public <T> Order(T[] args){
        this.id = (int) args[0];
        this.customer = (Customer) args[1];
        this.food = (Food) args[2];
        this.quantity = (int) args[3];
        this.status = Status.PENDING;
        this.special_requests = (String) args[4];
    }

    public void updateStatus(String status) {
        this.status = Status.valueOf(status);
    }
    
    public Status getStatus(){
        return this.status;
    }
    
    public int getQuantity(){
        return this.quantity;
    }
    
    public String getSpecial_requests(){
        return this.special_requests;
    }

    public void cancelOrder(){
        try {
            if(status.getPriority() > 3){
                status = Status.CANCELLED;
                Admin.cancelled_orders.add(this);
            } else{
                throw new LateCancellation("Cannot cancel");
            }
        } catch (LateCancellation e){
            System.out.println(e.getMessage());
        }
    }

    public enum Status{
        PENDING(7, "Pending"),
        PREPARING(6, "Preparing"),
        DENIED(5, "Denied"),
        CANCELLED(4, "Cancelled"),
        OUTFORDELIVERY(3, "Out For Delivery"),
        DELIVERED(2, "Delivered"),
        REFUNDED(1, "Refunded");

        private String status;
        private int priority;
        Status(int priority, String s) {
            this.priority = priority;
            this.status = s;
        }

        public String getStatus(){
            return this.status;
        }

        public int getPriority(){
            return this.priority;
        }
    }
}
