package com.example.assignment4_extension;

public class Cart {
    int id;
    Food food;
    int quantity;
    private Customer customer;

    Cart(int id, Food food, int quantity, Customer customer){
        this.id = id;
        this.food = food;
        this.quantity = quantity;
        this.customer = customer;
    }

    public void placeOrder(int id, String special_requests){
        Order order = new Order(new Object[]{id, customer, food, quantity, special_requests});
        if(!(customer instanceof VIP)){
            Admin.normal_orders.add(order);
        } else{
            Admin.vip_orders.add(order);
        }
    }


}
