package com.example.assignment4_extension;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;
import java.util.ArrayList;

import static com.example.assignment4_extension.Main.scenes;

public abstract class User implements MenuInterface {
    protected String name;

    public User(String name){
        this.name = name;
    }

    public static ArrayList<Admin> admins = new ArrayList<>();
    public static ArrayList<Customer> customers = new ArrayList<>();

    @Override
    public String viewMenu() {
        StringBuilder menu_items = new StringBuilder();
        for(Food item : Admin.items){
            menu_items.append("Item: ").append(item.name).append(" ").append("Price: ").append(item.price).append(" ").append("Category: ").append(item.category).append(" ").append("Availability: ").append(item.availability).append("\n");
        }
        return menu_items.toString();
    }

    public void createScene(String[] array, String path){
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(path));
            Parent root = fxmlLoader.load();
            Controller controller = fxmlLoader.getController();
            for(String s : array){
                String[] parts = s.split(" (?=\\w+:)");
                ArrayList<String> values = new ArrayList<>();
                for (String field : parts) {
                    String[] keyValue = field.split(": ", 2); // Split each field into key and value
                    if (keyValue.length == 2) {
                        values.add(keyValue[1]); // Add the value part to the ArrayList
                    }
                }
                controller.addItem(values);
            }
            Scene scene = new Scene(root, 800, 480);
            controller.initialize();
            scenes.add(scene);
        } catch (IOException e){
            e.printStackTrace();
        }

    }
}
