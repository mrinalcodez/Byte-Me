package com.example.assignment4_extension;

import javafx.fxml.FXML;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;

import java.util.ArrayList;

public abstract class Controller {

    @FXML
    public ScrollPane scrollPane;

    @FXML
    public GridPane gridPane;

    public abstract void addItem(ArrayList<String> arrayList);
    public abstract void initialize();
}
